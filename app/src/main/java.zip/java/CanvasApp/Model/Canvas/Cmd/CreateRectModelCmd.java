package CanvasApp.Model.Canvas.Cmd;

import CanvasApp.Model.Canvas.Event.ShapeAdded;
import CanvasApp.Factory.RectFactory;
import CanvasApp.Model.Shape.Leaf.ShapeModelLeaf;
import CanvasApp.Model.Shape.ShapeModel;

public class CreateRectModelCmd implements CreateShapeModelCmd {
    private final RectFactory factory = RectFactory.getInstance();
    private int x, y, w, h, z;
    private ShapeModel shapeModel;

    public CreateRectModelCmd() {}

    public CreateRectModelCmd(ShapeModel shapeModel, int x, int y, int w, int h, int z) {
        this.shapeModel = shapeModel;
        this.x = x; this.y = y; this.w = w; this.h = h; this.z = z;
    }

    @Override
    public void complete(ShapeModel shapeModel, int x, int y, int w, int h, int z) {
        this.shapeModel = shapeModel;
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.z = z;
    }

    @Override
    public void execute() {
        if(shapeModel == null) {
            return;
        }
        ShapeModelLeaf shapeModelLeaf = factory.createShapeModel(x, y, w, h, z);
        shapeModel.add(shapeModelLeaf);
        shapeModel.notify(new ShapeAdded(shapeModelLeaf, factory));
    }
}
