package CanvasApp.Model.Canvas.Event;

import CanvasApp.Model.Shape.Leaf.ShapeModelLeaf;
import CanvasApp.Model.Shape.ShapeModel;
import Observer.Event;
import Observer.Observer;

public abstract class CanvasComposition extends Event<ShapeModelLeaf> {
    public CanvasComposition(ShapeModelLeaf shapeModel){
        super(shapeModel);
    }

    @Override
    public void dispatch(Observer o) {
        if (o instanceof CanvasCompositionObserver observer) {
            dispatchCanvasModelEvent(observer);
        }
    }
    public abstract void dispatchCanvasModelEvent(CanvasCompositionObserver o);
}
