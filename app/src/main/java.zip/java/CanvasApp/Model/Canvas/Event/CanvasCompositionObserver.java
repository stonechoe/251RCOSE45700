package CanvasApp.Model.Canvas.Event;

import Observer.Observer;

public interface CanvasCompositionObserver extends Observer {
    void onShapeAdded(ShapeAdded event);
    void onShapeRemoved(ShapeRemoved event);
}
