package CanvasApp.Model.Canvas.Event;

import CanvasApp.Model.Shape.Leaf.ShapeModelLeaf;
import CanvasApp.Model.Shape.ShapeModel;

public class ShapeRemoved extends CanvasComposition {
    public ShapeRemoved(ShapeModelLeaf shapeModel) {
        super(shapeModel);
    }

    @Override
    public void dispatchCanvasModelEvent(CanvasCompositionObserver o) {
        o.onShapeRemoved(this);
    }
}