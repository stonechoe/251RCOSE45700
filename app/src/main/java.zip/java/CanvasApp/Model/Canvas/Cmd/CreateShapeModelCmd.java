package CanvasApp.Model.Canvas.Cmd;

import CanvasApp.Model.Shape.ShapeModel;
import Command.Command;

public interface CreateShapeModelCmd extends Command {
    void complete(ShapeModel shapeModel, int x, int y, int w, int h, int z);
}
