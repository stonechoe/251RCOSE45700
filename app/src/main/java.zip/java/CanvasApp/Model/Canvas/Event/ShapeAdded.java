package CanvasApp.Model.Canvas.Event;

import CanvasApp.Factory.ShapeFactory;
import CanvasApp.Model.Shape.Leaf.ShapeModelLeaf;

public class ShapeAdded extends CanvasComposition {
    public final ShapeFactory factory;
    public ShapeAdded(ShapeModelLeaf shapeModel, ShapeFactory factory){
        super(shapeModel);
        this.factory = factory;
    }

    @Override
    public void dispatchCanvasModelEvent(CanvasCompositionObserver o) {
        o.onShapeAdded(this);
    }
}
