package CanvasApp.Model.Shape.Leaf;

import CanvasApp.Model.Shape.Event.ShapeModelRealigned;
import CanvasApp.Model.Shape.ShapeModel;
import CanvasApp.Model.Shape.Event.ShapeModelMoved;
import CanvasApp.Model.Shape.Event.ShapeModelResized;

public abstract class ShapeModelLeaf extends ShapeModel {
    protected int x, y;
    protected int w, h;
    protected int z;
    protected String id;
    protected int padding = 2;

    public ShapeModelLeaf(String id, int x, int y, int w, int h, int z) {
        this.id = id;
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.z = z;
    }

    @Override
    public String getId() {
        return id;
    }
    @Override
    public int getX() {return x;}
    @Override
    public int getY() {
        return y;
    }
    @Override
    public int getW() {
        return w;
    }
    @Override
    public int getH() {
        return h;
    }
    @Override
    public int getZ() {
        return z;
    }

    @Override
    public void move(int dx, int dy) {
        int newX = x + dx; int newY = y + dy;
        if(newX > 0) this.x = newX;
        if(newY > 0) this.y = newY;
        notify(new ShapeModelMoved(this));
    }

    @Override
    public void resize(int dw, int dh) {
        int newW = w + dw; int newH = h + dh;
        if(newW > 0) this.w = newW;
        if(newH > 0) this.h = newH;
        notify(new ShapeModelResized(this));
    }

    @Override
    public void realign(int z) {
        if(z > 0) this.z = z;
        notify(new ShapeModelRealigned(this));
    }

    @Override
    public void add(ShapeModel shape) {
        throw new UnsupportedOperationException("add not supported on leaf");
    }

    @Override
    public void remove(ShapeModel shape) {
        throw new UnsupportedOperationException("remove not supported on leaf");
    }
}
