package CanvasApp.Model.Shape.Event;

import CanvasApp.Model.Shape.ShapeModel;

public class ShapeModelResized extends ShapeModelEvent {
    public ShapeModelResized(ShapeModel source) {
        super(source);
    }

    @Override
    public void dispatchShapeModelEvent(ShapeModelEventHandler handler) {
        handler.onShapeResized(this);
    }
}
