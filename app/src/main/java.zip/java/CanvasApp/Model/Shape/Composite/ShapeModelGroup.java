package CanvasApp.Model.Shape.Composite;

import CanvasApp.Model.Shape.Event.ShapeModelMoved;
import CanvasApp.Model.Shape.Event.ShapeModelRealigned;
import CanvasApp.Model.Shape.Event.ShapeModelResized;
import CanvasApp.Model.Shape.ShapeModel;
import Command.Command;

import java.util.UUID;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class ShapeModelGroup extends ShapeModel {
    private final Map<String, ShapeModel> members = new HashMap<>();
    private final String id = UUID.randomUUID().toString();

    @Override
    public String getId() {
        return id;
    }

    @Override
    public int getX() {
        if (members.isEmpty()) return 0;
        int baseX = members.values().iterator().next().getX();
        for (ShapeModel s : members.values()) {
            if (s.getX() != baseX) return -1; // sentinel
        }
        return baseX;
    }

    @Override
    public int getY() {
        if (members.isEmpty()) return 0;
        int baseY = members.values().iterator().next().getY();
        for (ShapeModel s : members.values()) {
            if (s.getY() != baseY) return -1;
        }
        return baseY;
    }

    @Override
    public int getW() {
        if (members.isEmpty()) return 0;
        int baseW = members.values().iterator().next().getW();
        for (ShapeModel s : members.values()) {
            if (s.getW() != baseW) return -1;
        }
        return baseW;
    }

    @Override
    public int getH() {
        if (members.isEmpty()) return 0;
        int baseH = members.values().iterator().next().getH();
        for (ShapeModel s : members.values()) {
            if (s.getH() != baseH) return -1;
        }
        return baseH;
    }

    @Override
    public int getZ() {
        if (members.isEmpty()) return 0;
        int baseZ = members.values().iterator().next().getZ();
        for (ShapeModel s : members.values()) {
            if (s.getZ() != baseZ) return -1;
        }
        return baseZ;
    }

    @Override
    public void move(int dx, int dy) {
        for (ShapeModel shape : members.values()) {
            shape.move(dx, dy);
        }
        notify(new ShapeModelMoved(this));
    }

    @Override
    public void resize(int dw, int dh) {
        for (ShapeModel shape : members.values()) {
            shape.resize(dw, dh);
        }
        notify(new ShapeModelResized(this));
    }

    @Override
    public void realign(int z) {
        for (ShapeModel shape : members.values()) {
            shape.realign(z);
        }
        notify(new ShapeModelRealigned(this));
    }

    @Override
    public void add(ShapeModel shapeModel) {
        members.put(shapeModel.getId(), shapeModel);
    }

    @Override
    public void remove(ShapeModel shapeModel) {
        members.remove(shapeModel.getId());
    }

    public boolean contains(String id) {
        return members.containsKey(id);
    }

    public Collection<ShapeModel> getChildren() {
        return members.values();
    }

    public void clear() {
        members.clear();
    }

    public void handleCmd(Command cmd) {
        cmd.execute();
    }
}
