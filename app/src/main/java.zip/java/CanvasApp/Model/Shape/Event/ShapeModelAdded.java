package CanvasApp.Model.Shape.Event;

import CanvasApp.Model.Shape.ShapeModel;
import CanvasApp.Factory.ShapeFactory;

public class ShapeModelAdded extends ShapeModelEvent {
    public final ShapeFactory factory;
    public ShapeModelAdded(ShapeModel source, ShapeFactory factory) {
        super(source);
        this.factory = factory;
    }

    @Override
    public void dispatchShapeModelEvent(ShapeModelEventHandler handler) {
        handler.onShapeAdded(this);
    }
} 