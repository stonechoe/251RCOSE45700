package CanvasApp.Model.Shape.Event;

import Observer.Observer;

public interface ShapeModelEventHandler extends Observer {
    void onShapeAdded(ShapeModelAdded event);
    void onShapeRemoved(ShapeModelRemoved event);
    void onShapeMoved(ShapeModelMoved event);
    void onShapeResized(ShapeModelResized event);
    void onShapeRealigned(ShapeModelRealigned event);
} 