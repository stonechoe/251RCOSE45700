package CanvasApp.Model.Shape.Event;

import CanvasApp.Model.Shape.ShapeModel;
import Observer.Event;

public abstract class ShapeModelEvent extends Event<ShapeModel> {
    public ShapeModelEvent(ShapeModel source) {
        super(source);
    }

    @Override
    public void dispatch(Observer.Observer o) {
        if (o instanceof ShapeModelEventHandler handler) {
            dispatchShapeModelEvent(handler);
        }
    }

    public abstract void dispatchShapeModelEvent(ShapeModelEventHandler handler);
} 