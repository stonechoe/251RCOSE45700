package CanvasApp.Model.Shape.Event;

import CanvasApp.Model.Shape.ShapeModel;

public class ShapeModelRemoved extends ShapeModelEvent {
    public ShapeModelRemoved(ShapeModel source) {
        super(source);
    }

    @Override
    public void dispatchShapeModelEvent(ShapeModelEventHandler handler) {
        handler.onShapeRemoved(this);
    }
} 