package CanvasApp.Model.Shape.Event;

import CanvasApp.Model.Shape.ShapeModel;

public class ShapeModelMoved extends ShapeModelEvent {
    public ShapeModelMoved(ShapeModel source) {
        super(source);
    }

    @Override
    public void dispatchShapeModelEvent(ShapeModelEventHandler handler) {
        handler.onShapeMoved(this);
    }
}
