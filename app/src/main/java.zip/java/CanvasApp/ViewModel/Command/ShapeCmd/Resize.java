package CanvasApp.ViewModel.Command.ShapeCmd;

import CanvasApp.ViewModel.CanvasVM;
import Command.Command;

public class Resize implements Command {
    CanvasVM canvasVM;
    int dw,dh;

    public Resize(CanvasVM canvasVM, int dw, int dh) {
        this.canvasVM = canvasVM;
        this.dw = dw;
        this.dh = dh;
    }

    @Override
    public void execute() {
        canvasVM.selected.resize(dw,dh);
    }
}
