package CanvasApp.ViewModel.Command.CreateShapeCmd;

import CanvasApp.Model.Canvas.Cmd.CreateRectModelCmd;
import CanvasApp.ViewModel.CanvasVM;
import Command.Command;

public class CreateRectSelectedCmd implements Command {
    CanvasVM canvasVM;
    public CreateRectSelectedCmd(CanvasVM canvasVM) {
        this.canvasVM = canvasVM;
    }

    public void execute() {
        System.out.println("[ToolCmd] CreateRectSelectedCmd executed");
        canvasVM.setTempCreateCmd(new CreateRectModelCmd());
        canvasVM.setCanvasDraggable(true);
    }
}
