package CanvasApp.ViewModel;

import CanvasApp.Model.Canvas.Cmd.CreateShapeModelCmd;
import CanvasApp.Model.Shape.Composite.ShapeModelGroup;
import CanvasApp.Model.Shape.ShapeModel;
import CanvasApp.ViewModel.CanvasData.CanvasData;
import CanvasApp.ViewModel.EventHandler.CanvasShapeModelEventHandler;
import CanvasApp.ViewModel.EventHandler.SelectedShapeModelEventHandler;
import CanvasApp.ViewModel.PropertyData.PropertyData;
import Command.Command;

public class CanvasVM {
    private final ShapeModelGroup canvas = new ShapeModelGroup();
    public final ShapeModelGroup selected = new ShapeModelGroup();

    private final CanvasData canvasData;
    private CreateShapeModelCmd tempCreateCmd;
    private final PropertyData propertyData = new PropertyData();

    public CanvasVM(CanvasData canvasData) {
        this.canvasData = canvasData;
        canvas.attach(new CanvasShapeModelEventHandler(canvasData));
        selected.attach(new SelectedShapeModelEventHandler(propertyData));
    }

    public ShapeModel getShape(String id) {
        return canvas.getChildren().stream()
                .filter(shape -> shape.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public void deSelectAll() {
        selected.clear();
    }

    public void handleSelect(ShapeModel shapeModel) {
        if (selected.contains(shapeModel.getId())) {
            selected.remove(shapeModel);
        } else {
            selected.add(shapeModel);
        }
    }

    public void handleCmd(Command command) {
        command.execute();
    }

    public void setTempCreateCmd(CreateShapeModelCmd tempCreateCmd) {
        this.tempCreateCmd = tempCreateCmd;
    }

    public void setCanvasDraggable(boolean draggable) {
        canvasData.setCanvasViewState(draggable);
    }

    public void completeTempCreateCmd(int x, int y, int w, int h, int z) {
        tempCreateCmd.complete(canvas, x, y, w, h, z);
        canvas.handleCmd(tempCreateCmd);
    }
}
