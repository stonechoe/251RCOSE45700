package CanvasApp.ViewModel.ShapeData.Event;

import CanvasApp.ViewModel.ShapeData.ShapeData;

public class ShapeDataMoved extends ShapeDataEvent {
    public ShapeDataMoved(ShapeData shapeData) {
        super(shapeData);
    }

    @Override
    public void dispatchShapeDataEvent(ShapeDataObserver o) {
        o.onMoved(this);
    }
}
