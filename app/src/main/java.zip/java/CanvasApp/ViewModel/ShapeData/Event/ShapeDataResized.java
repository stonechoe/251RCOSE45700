package CanvasApp.ViewModel.ShapeData.Event;

import CanvasApp.ViewModel.ShapeData.ShapeData;

public class ShapeDataResized extends ShapeDataEvent {
    public ShapeDataResized(ShapeData shapeData) {
        super(shapeData);
    }

    @Override
    public void dispatchShapeDataEvent(ShapeDataObserver o) {
        o.onResized(this);
    }
}
