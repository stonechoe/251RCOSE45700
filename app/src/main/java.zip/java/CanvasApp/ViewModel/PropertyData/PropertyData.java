package CanvasApp.ViewModel.PropertyData;

import CanvasApp.Model.Shape.Composite.ShapeModelGroup;
import Observer.*;

public class PropertyData extends Observable {
    private ShapeModelGroup selected;

    private void notifyPanel() {
    }

    public int getX() { return selected.getX(); }
    public int getY() { return selected.getY(); }
    public int getW() { return selected.getW(); }
    public int getH() { return selected.getH(); }
    public int getZ() { return selected.getZ(); }

}

