package CanvasApp.ViewModel.CanvasData.Event;

import CanvasApp.ViewModel.CanvasData.CanvasData;

public class CanvasDataDraggableSet extends CanvasDataEvent<CanvasData> {

    public CanvasDataDraggableSet(CanvasData canvasData) {
        super(canvasData);
    }

    @Override
    public void dispatchCanvasDataEvent(CanvasDataObserver o) {
        System.out.println("[CanvasDataDraggableSet] dispatching to observer");
        o.onCanvasDataDraggableSet(this);
    }

}
