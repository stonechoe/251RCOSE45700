package CanvasApp.ViewModel.CanvasData.Event;

import CanvasApp.ViewModel.ShapeData.ShapeData;

public class CanvasDataShapeRemoved extends CanvasDataEvent<ShapeData> {

    public CanvasDataShapeRemoved(ShapeData shapeData) {
        super(shapeData);
    }

    @Override
    public void dispatchCanvasDataEvent(CanvasDataObserver o) {
        o.onShapeRemoved(this);
    }
}
