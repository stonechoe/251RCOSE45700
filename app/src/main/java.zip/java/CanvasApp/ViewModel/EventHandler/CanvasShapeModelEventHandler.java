package CanvasApp.ViewModel.EventHandler;

import CanvasApp.Model.Shape.Event.*;
import CanvasApp.ViewModel.CanvasData.CanvasData;
import CanvasApp.ViewModel.ShapeData.ShapeData;

public class CanvasShapeModelEventHandler implements ShapeModelEventHandler {
    private final CanvasData canvasData;

    public CanvasShapeModelEventHandler(CanvasData canvasData) {
        this.canvasData = canvasData;
    }

    @Override
    public void onShapeAdded(ShapeModelAdded event) {
        canvasData.addShape(event.source, event.factory);
    }

    @Override
    public void onShapeRemoved(ShapeModelRemoved event) {
        canvasData.removeShape(event.source.getId());
    }

    @Override
    public void onShapeMoved(ShapeModelMoved event) {
        ShapeData shapeData = canvasData.getShapeData(event.source.getId());
        shapeData.updatePosition(event.source.getX(), event.source.getY());
    }

    @Override
    public void onShapeResized(ShapeModelResized event) {
        ShapeData shapeData = canvasData.getShapeData(event.source.getId());
        shapeData.updateSize(event.source.getW(), event.source.getH());
    }

    @Override
    public void onShapeRealigned(ShapeModelRealigned event) {
        ShapeData shapeData = canvasData.getShapeData(event.source.getId());
        shapeData.updateZ(event.source.getZ());
        canvasData.realign(shapeData);
    }

} 