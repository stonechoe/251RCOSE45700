package CanvasApp.ViewModel.EventHandler;

import CanvasApp.Model.Shape.Event.*;
import CanvasApp.ViewModel.CanvasData.CanvasData;
import CanvasApp.ViewModel.PropertyData.PropertyData;

public class SelectedShapeModelEventHandler implements ShapeModelEventHandler {
    private final PropertyData propertyData;

    public SelectedShapeModelEventHandler(PropertyData propertyData) {
        this.propertyData = propertyData;
    }

    @Override
    public void onShapeAdded(ShapeModelAdded event) {
        // Selected group doesn't need to handle add events
    }

    @Override
    public void onShapeRemoved(ShapeModelRemoved event) {
        // Selected group doesn't need to handle remove events
    }

    @Override
    public void onShapeMoved(ShapeModelMoved event) {
        // Selected group doesn't need to handle move events
    }

    @Override
    public void onShapeResized(ShapeModelResized event) {

    }

    @Override
    public void onShapeRealigned(ShapeModelRealigned event) {

    }
}