package CanvasApp.View.PropertyView;

import CanvasApp.Model.Shape.ShapeModel;
import CanvasApp.ViewModel.CanvasVM;
import Observer.Observer;

import javax.swing.*;
import java.awt.*;

public class PropertyView extends JPanel implements Observer {
    private final CanvasVM viewModel;

    private final JTextField xField = new JTextField();
    private final JTextField yField = new JTextField();
    private final JTextField wField = new JTextField();
    private final JTextField hField = new JTextField();

    public PropertyView(CanvasVM viewModel) {
        this.viewModel = viewModel;
        setLayout(new GridLayout(4, 2));

        add(new JLabel("X:")); add(xField);
        add(new JLabel("Y:")); add(yField);
        add(new JLabel("W:")); add(wField);
        add(new JLabel("H:")); add(hField);

        xField.addActionListener(e -> handleUpdate("x"));
        yField.addActionListener(e -> handleUpdate("y"));
        wField.addActionListener(e -> handleUpdate("w"));
        hField.addActionListener(e -> handleUpdate("h"));
    }

    public void refresh() {
        ShapeModel selected = viewModel.selected;

        int x = selected.getX();
        int y = selected.getY();
        int w = selected.getW();
        int h = selected.getH();

        xField.setText(x == -1 ? "--" : String.valueOf(x));
        yField.setText(y == -1 ? "--" : String.valueOf(y));
        wField.setText(w == -1 ? "--" : String.valueOf(w));
        hField.setText(h == -1 ? "--" : String.valueOf(h));
    }

    private void handleUpdate(String field) {
        try {
            int value = 0;
            switch (field) {
                case "x": value = Integer.parseInt(xField.getText()); break;
                case "y": value = Integer.parseInt(yField.getText()); break;
                case "w": value = Integer.parseInt(wField.getText()); break;
                case "h": value = Integer.parseInt(hField.getText()); break;
            }

            ShapeModel selected = viewModel.selected;
            switch (field) {
                case "x": selected.move(value - selected.getX(), 0); break;
                case "y": selected.move(0, value - selected.getY()); break;
                case "w": selected.resize(value - selected.getW(), 0); break;
                case "h": selected.resize(0, value - selected.getH()); break;
            }
        } catch (NumberFormatException ignored) {
            // invalid input; ignore update
        }
    }
}
