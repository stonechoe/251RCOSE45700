package CanvasApp.View.CanvasView;

import CanvasApp.View.ShapeView.ShapeView;
import CanvasApp.ViewModel.CanvasData.Event.*;
import CanvasApp.ViewModel.CanvasVM;
import CanvasApp.ViewModel.CanvasData.CanvasData;
import CanvasApp.ViewModel.Command.CreateShapeCmd.CompleteCreateCmd;
import CanvasApp.ViewModel.Command.ShapeCmd.Realign;
import CanvasApp.ViewModel.ShapeData.Event.ShapeDataRealigned;
import CanvasApp.ViewModel.ShapeData.ShapeData;
import Command.Command;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import static utils.MathUtil.computeRectangle;

public class CanvasView extends JPanel implements CanvasDataObserver {
    private final CanvasVM viewModel;
    private final CanvasData canvasData;
    private final JTextField zField = new JTextField();
    private final JLayeredPane layeredPane = new JLayeredPane();
    private final JPanel glassPane = new JPanel();
    private Point dragStart = null;

    public CanvasView(CanvasVM viewModel, CanvasData canvasData) {
        this.viewModel = viewModel;
        this.canvasData = canvasData;
        canvasData.attach(this);
        setLayout(null);
        initUI();
        initGlassPane();
    }

    private void initUI() {
        layeredPane.setBounds(0, 0, 800, 600);
        layeredPane.setLayout(null);
        this.add(layeredPane);
        layeredPane.add(glassPane, JLayeredPane.DRAG_LAYER);

        zField.setBounds(120, 50, 50, 25);
        zField.addActionListener(e -> {
            String zText = zField.getText().trim();
            try {
                int newZ = Integer.parseInt(zText);
                viewModel.handleCmd(new Realign(viewModel, newZ));
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "숫자를 입력하세요!");
            }
        });

        this.add(zField);
    }

    private void initGlassPane() {
        glassPane.setBounds(0, 0, layeredPane.getWidth(), layeredPane.getHeight());
        glassPane.setOpaque(false);
        glassPane.setVisible(false);

        glassPane.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                dragStart = e.getPoint();
                System.out.println("[CanvasView] mousePressed: " + dragStart);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                Point dragEnd = e.getPoint();
                Rectangle dragRect = computeRectangle(dragStart, dragEnd);
                Command cmd = new CompleteCreateCmd(viewModel, dragRect.x, dragRect.y, dragRect.width, dragRect.height, canvasData.getMaxZ() + 1);
                viewModel.handleCmd(cmd);
            }
        });
    }

    public Component findComponentById(String id) {
        for (Component comp : layeredPane.getComponents()) {
            if (id.equals(comp.getName())) {
                return comp;
            }
        }
        return null;
    }

    @Override
    public void onShapeAdded(CanvasDataShapeAdded event) {
        String id = event.source.getId();
        ShapeData shapeData = canvasData.getShapeData(id);
        ShapeView shapeView = event.shapeFactory.createShapeView(shapeData, viewModel);
        layeredPane.add(shapeView);
        layeredPane.setLayer(shapeView, shapeData.getZ());
        shapeView.repaint();
    }

    @Override
    public void onShapeRemoved(CanvasDataShapeRemoved event) {
        String id = event.source.getId();
        Component component = findComponentById(id);
        layeredPane.remove(component);
    }

    @Override
    public void onRealigned(CanvasDataShapeRealigned event) {
        String id = event.source.getId();
        Component component = findComponentById(id);
        layeredPane.setLayer(component, event.source.getZ());
    }

    @Override
    public void onCanvasDataDraggableSet(CanvasDataDraggableSet event) {
        setGlassVisible(event.source.isDraggable());
    }

    public void setGlassVisible(boolean glassVisible) {
        System.out.println("[CanvasView] setGlassVisible = " + glassVisible);
        glassPane.setVisible(glassVisible);
    }
}
