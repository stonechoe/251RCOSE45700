package Observer;

public interface Observer {}
